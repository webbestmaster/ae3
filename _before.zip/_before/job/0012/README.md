# Gem4me - webApp

## Install
>$ npm i

## Setup
- setup eslint for your IDE

## Run
>$ npm start
After that open in your browser http://localhost:8080/

