export default {

    languageName: 'English',
    languageNameAlpha2: 'En',
    languageNameAlpha3: 'Eng',

    language: 'Language'

};
