export default {

    languageName: 'Русский',
    languageNameAlpha2: 'Ру',
    languageNameAlpha3: 'Рус',

    language: 'Язык'

};
