/**
 * Created by dmitry.turovtsov on 10.04.2017.
 */


/**
 * Created by dmitry.turovtsov on 10.04.2017.
 */

import {combineReducers} from 'redux';

import loginState from './login/reducer';

export default combineReducers({
    loginState
});
