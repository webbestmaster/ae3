export changeLanguage from './change-language';
// export click from './click';
export resizeScreen from './resizeScreen';
