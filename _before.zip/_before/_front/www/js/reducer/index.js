export screen from './screen';
// export click from './click';
export currentLanguage from './change-language';

export gameCreating from './../component/create-room/reducer';
export joinRoom from './../component/join-room/reducer';
export chatMessages from './../component/chat/reducer';
