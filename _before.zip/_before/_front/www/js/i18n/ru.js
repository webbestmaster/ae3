export default {

    LANGUAGE_NAME: 'Русский',
    LANGUAGE_NAME_ALPHA_2: 'Ру',
    LANGUAGE_NAME_ALPHA_3: 'Рус',

    language: 'язык',

/*
    // settings
    settings: 'настройки',
    difficult: 'сложность',
    ease: 'легко',
    normal: 'нормально',
    hard: 'трудно',
    player: 'игрок',
    human: 'человек',
    ai: 'ИИ',
    start: 'старт',
    wait_for: 'ждём ход',

    // other
    press_again_to_exit: 'Нажмите еще раз для выхода'
*/

};
