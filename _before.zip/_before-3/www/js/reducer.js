/**
 * Created by dmitry.turovtsov on 26.04.2017.
 */

// usual component
export appState from './app/reducer';
export userState from './user/reducer';
export gameState from './game/reducer';
