import {Unit} from './base-unit';

class Golem extends Unit {
}

export {Golem};
