import {Unit} from './base-unit';

class Galamar extends Unit {
}

export {Galamar};
