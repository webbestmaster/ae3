import {Unit} from './base-unit';

class Soldier extends Unit {
}

export {Soldier};
