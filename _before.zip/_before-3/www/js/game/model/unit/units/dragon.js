import {Unit} from './base-unit';

class Dragon extends Unit {
}

export {Dragon};
