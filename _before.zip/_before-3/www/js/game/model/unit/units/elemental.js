import {Unit} from './base-unit';

class Elemental extends Unit {
}

export {Elemental};
