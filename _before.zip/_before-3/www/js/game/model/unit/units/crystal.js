import {Unit} from './base-unit';

class Crystal extends Unit {
}

export {Crystal};
