import {Unit} from './base-unit';

class Valadorn extends Unit {
}

export {Valadorn};
