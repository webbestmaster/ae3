export default {

    LANGUAGE_NAME: 'English',
    LANGUAGE_NAME_ALPHA_2: 'En',
    LANGUAGE_NAME_ALPHA_3: 'Eng',

    language: 'language',

/*
    // settings
    settings: 'settings',
    difficult: 'difficult',
    ease: 'ease',
    normal: 'normal',
    hard: 'hard',
    player: 'player',
    human: 'human',
    ai: 'AI',
    start: 'start',
    wait_for: 'wait for',

    // other
    press_again_to_exit: 'Press again to exit'
*/

};
