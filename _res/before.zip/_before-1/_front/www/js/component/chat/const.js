export default {
    CHAT_ADD_MESSAGE: 'CHAT_ADD_MESSAGE'
};
