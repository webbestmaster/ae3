// run http server
require('./server/http');

// run ws server
require('./server/ws');
