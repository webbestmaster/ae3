### ae3
ae3

####To install all dependencies (for front and back and main)
>$ npm i

####Errors:
>Accessing PropTypes via the main React package is deprecated. Use the prop-types package from npm instead.

>RouterContext: React.createClass is deprecated and will be removed in version 16. Use plain JavaScript classes instead. If you're not yet ready to migrate, create-react-class is available on npm as a drop-in replacement.

Will fixed in next versions of libraries.
