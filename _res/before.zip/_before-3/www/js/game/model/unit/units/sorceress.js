import {Unit} from './base-unit';

class Sorceress extends Unit {
}

export {Sorceress};
