import {Unit} from './base-unit';

class Skeleton extends Unit {
}

export {Skeleton};
