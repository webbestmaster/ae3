import {Unit} from './base-unit';

class Wisp extends Unit {
}

export {Wisp};
