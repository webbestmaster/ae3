import {Unit} from './base-unit';

class Saeth extends Unit {
}

export {Saeth};
