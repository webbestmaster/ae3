import {Unit} from './base-unit';

class DemonLord extends Unit {
}

export {DemonLord};
