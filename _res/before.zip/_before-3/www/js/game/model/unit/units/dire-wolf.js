import {Unit} from './base-unit';

class DireWolf extends Unit {
}

export {DireWolf};
