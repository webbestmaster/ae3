import {Unit} from './base-unit';

class Archer extends Unit {
}

export {Archer};
