import app from './components/app/reducer';

export {
    app
};
