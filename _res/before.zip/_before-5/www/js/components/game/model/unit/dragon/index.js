// @flow
import Unit from './../index';

export default class Dragon extends Unit {
}
