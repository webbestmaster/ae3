// @flow
import Unit from './../index';

export default class SaethHeavensFury extends Unit {
}
