// @flow
import Unit from './../index';

export default class DemonLord extends Unit {
}
