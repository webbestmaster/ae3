// @flow
import Unit from './../index';

export default class Wisp extends Unit {
}
