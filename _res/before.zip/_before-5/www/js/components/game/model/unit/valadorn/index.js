// @flow
import Unit from './../index';

export default class Valadorn extends Unit {
}
