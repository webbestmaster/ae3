// @flow
import Unit from './../index';

export default class Saeth extends Unit {
}
