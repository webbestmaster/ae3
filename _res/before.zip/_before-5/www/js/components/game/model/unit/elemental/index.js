// @flow
import Unit from './../index';

export default class Elemental extends Unit {
}
