// @flow
import Unit from './../index';

export default class DireWolf extends Unit {
}
