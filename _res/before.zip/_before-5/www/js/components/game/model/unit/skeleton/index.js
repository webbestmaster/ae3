// @flow
import Unit from './../index';

export default class Skeleton extends Unit {
}
