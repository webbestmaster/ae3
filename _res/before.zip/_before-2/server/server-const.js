/* eslint no-process-env: 0 */
const httpPort = process.env.PORT || 3000;
// const WS_PORT = httpPort + 1;

module.exports = {
    httpPort
    // WS_PORT
};
