/**
 * Created by dim on 8.5.17.
 */
module.exports = {
    fnc: 'function',
    obj: 'object',
    str: 'string',
    nbr: 'number',
    bln: 'boolean',
    arr: 'array'
};
